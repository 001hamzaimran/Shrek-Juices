# Pakistan-Digital-Map

This repo contains district wise SVG based editable and interactive map of Pakistan.

![SVG Map of Pakistan](https://github.com/codeforpakistan/Pakistan-Digital-Map/blob/master/img/Pakistan%20map.png "SVG Map of Pakistan")
